

x = 10

print x


def fn1():
    pass


def fn2():
    pass

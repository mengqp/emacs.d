/* @flow */

function square(n: number): number {
    return n * n;
}

square(2);
